package com.orange.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	WebDriver driver;

	@FindBy(name="username")
	private WebElement userNameField;
	
	@FindBy(name="password")
	private WebElement passwordField;
	
	@FindBy(xpath="//*[contains(@class, 'orangehrm-login-button')]")
	private WebElement loginBtn;
	
	@FindBy(xpath = "//p[@class='oxd-text oxd-text--p oxd-alert-content-text']")
    private WebElement errorMessage;
	
	@FindBy(xpath = "//*[@class='oxd-topbar-header-userarea']")
	private WebElement homePageHeader;
	
	@FindBy(xpath = "//p[text()='Invalid credentials']")
	private WebElement inValidCredentialsErrorMsg;
	
	@FindBy(xpath = "(//*[contains(@class, 'oxd-input-group__message')])[1]")
	private WebElement userNameReqErrorMsg;
	
	@FindBy(xpath = "(//*[contains(@class, 'oxd-input-group__message')])[2]")
	private WebElement passwordReqErrorMsg;
	
	@FindBy(xpath = "//p[contains(@class,'orangehrm-login-forgot-header')]")
	private WebElement forgotPassword;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void enterUserName(String userName) {
		userNameField.sendKeys(userName);
	}
	
	public void enterPassword(String password) {
		passwordField.sendKeys(password);
	}
	
	public void clickLoginBtn() {
		loginBtn.click();
	}
	
	public String getErrorMsg() {
		return errorMessage.getText();
	}
	
	public boolean headerAfterLoginDisplay() {
		return homePageHeader.isDisplayed();
	}
	
	public boolean inValidCredentialsErrMsg() {
		return inValidCredentialsErrorMsg.isDisplayed();
	}
	
	public boolean noUserCred() {
		return userNameReqErrorMsg.isDisplayed();
	}
	
	public boolean noPasswordCred() {
		return passwordReqErrorMsg.isDisplayed();
	}
	
	public void clickForgetPasswordBtn() {
		forgotPassword.click();
	}
}
