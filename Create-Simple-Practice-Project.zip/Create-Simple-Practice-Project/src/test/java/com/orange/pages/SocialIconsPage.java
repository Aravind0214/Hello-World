package com.orange.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SocialIconsPage {
	WebDriver driver;
	
	@FindBy(xpath = "//a[@href='https://www.linkedin.com/company/orangehrm/mycompany/']")
	private WebElement linkedIn;
	
	@FindBy(xpath = "//a[@href='https://www.facebook.com/OrangeHRM/']")
	private WebElement faceBook;
	
	@FindBy(xpath = "//a[@href='https://twitter.com/orangehrm?lang=en']")
	private WebElement twitter;
	
	@FindBy(xpath = "//a[@href='https://www.youtube.com/c/OrangeHRMInc']")
	private WebElement youTube;
	
	public SocialIconsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void clickLinkedInIcon() {
		linkedIn.click();
	}
	
	public void clickFacebookIcon() {
		faceBook.click();
	}
	
	public void clickTwitterIcon() {
		twitter.click();
	}
	
	public void clickYouTubeIcon() {
		youTube.click();
	}
}
