package com.orange.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.orange.pages.LoginPage;
import com.orange.utils.Base;

public class LoginPageTests extends Base {

	@Test(priority = 0)
	public void validUserNameValidPassword() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUserName("Admin");
		loginPage.enterPassword("admin123");
		loginPage.clickLoginBtn();

		Assert.assertTrue(loginPage.inValidCredentialsErrMsg(), "User did not login successfully");
	}

	@Test(priority = 1)
	public void invalidUserNameValidPassword() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUserName("AAAdmin");
		loginPage.enterPassword("admin123");
		loginPage.clickLoginBtn();

		Assert.assertTrue(loginPage.inValidCredentialsErrMsg(), "Error message not displayed for invalid credentials");
	}

	@Test(priority = 2)
	public void validUserNameInValidPassword() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUserName("Admin");
		loginPage.enterPassword("aaadmin123");
		loginPage.clickLoginBtn();

		Assert.assertTrue(loginPage.inValidCredentialsErrMsg(), "Error message not displayed for invalid credentials");
	}

	@Test(priority = 3)
	public void invalidUserNameInValidPassword() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUserName("AAAdmin");
		loginPage.enterPassword("aaaadmin123");
		loginPage.clickLoginBtn();

		Assert.assertTrue(loginPage.inValidCredentialsErrMsg(), "Error message not displayed for invalid credentials");
	}

	@Test(priority = 4)
	public void noCredentials() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.clickLoginBtn();
		assert loginPage.noUserCred() : "User name error message is not displayed";
		assert loginPage.noPasswordCred() : "Password error message is not displayed";
	}

	@Test(priority = 5)
	public void navigateToForgetPassword() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.clickForgetPasswordBtn();
		String currentURL = driver.getCurrentUrl();
		if (currentURL.contains("requestPasswordResetCode")) {
			System.out.println("Navigated to reset password page");
		} else {
			System.out.println("Navigation is not to reset password page");
		}
	}
}
