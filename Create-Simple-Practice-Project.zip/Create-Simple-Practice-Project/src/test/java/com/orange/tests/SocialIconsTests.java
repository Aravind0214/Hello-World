package com.orange.tests;

import java.util.Iterator;
import java.util.Set;

import org.testng.annotations.Test;

import com.orange.pages.SocialIconsPage;
import com.orange.utils.Base;

public class SocialIconsTests extends Base {

	@Test(priority = 0)
	public void linkedInRedirection() throws InterruptedException {
		SocialIconsPage socialIcon = new SocialIconsPage(driver);
//		String originalHandle = driver.getWindowHandle();
		socialIcon.clickLinkedInIcon();
		socialIcon.clickFacebookIcon();

		// Switch to new tab
		Set<String> handles = driver.getWindowHandles();
		Iterator<String> it = handles.iterator();
		String parentWindow = it.next();
		String linkedInWindow = it.next();
		String facebookWindow = it.next();

		driver.switchTo().window(linkedInWindow);
		System.out.println(driver.getCurrentUrl());
		Thread.sleep(3000);
		driver.switchTo().window(parentWindow);
		System.out.println(driver.getCurrentUrl());
		Thread.sleep(3000);
		driver.switchTo().window(facebookWindow);
		System.out.println(driver.getCurrentUrl());
		
		
		
		driver.close();
//		socialIcon.clickFacebookIcon();
//		String fbWindow = it.next();
//		driver.switchTo().window(fbWindow);
//		System.out.println(driver.getCurrentUrl());
//		driver.switchTo().window(parentWindow);

	}
}
