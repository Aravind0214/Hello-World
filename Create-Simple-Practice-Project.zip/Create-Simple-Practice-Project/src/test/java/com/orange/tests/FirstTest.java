package com.orange.tests;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.orange.utils.Base;

public class FirstTest extends Base {
	@Test(priority = 2)
	public void testLoginPage() throws InterruptedException {
		String pageTitle = driver.getTitle();
		System.out.println(pageTitle);
		String expectedTitle = "OrangeHRM";
		Assert.assertEquals(pageTitle, expectedTitle, "Title does not match");
		driver.quit();
	}

	@Test(priority = 0)
	public void validInputCredentials() throws InterruptedException {
		driver.findElement(By.xpath("//*[@name='username']")).sendKeys("Admin");
		driver.findElement(By.xpath("//*[@name='password']")).sendKeys("AAdmin123");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[contains(@class, 'orangehrm-login-button')]")).click();

		try {
			WebElement userLoggedInSuccess = driver.findElement(By.xpath("//*[@class='oxd-topbar-header-userarea']"));
			if (userLoggedInSuccess.isDisplayed()) {
				System.out.println("User logged in successfully");
			}
		} catch (NoSuchElementException e) {
			System.out.println("User logging failed");
		}
	}

	@Test(priority = 1)
	public void invalidInputCredentials() throws InterruptedException {
		driver.findElement(By.xpath("//*[@name='username']")).sendKeys("admin123");
		driver.findElement(By.xpath("//*[@name='password']")).sendKeys("admin123");
		driver.findElement(By.xpath("//*[contains(@class, 'orangehrm-login-button')]")).click();
		Thread.sleep(5000);
		WebElement errorMsg = driver.findElement(By.xpath("//p[@class='oxd-text oxd-text--p oxd-alert-content-text']"));
		String expectedMsg = "Invalid credentials";
		Assert.assertEquals(errorMsg.getText(), expectedMsg);
	}
}
